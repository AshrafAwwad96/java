package model;

public class Admin extends User {
    public Admin(String username) {
        super(username, "Admin");
    }

    @Override
    public void accessSystem() {
        System.out.println("Admin access granted.");
    }
}
