package model;

public class Guest extends User {
    public Guest(String username) {
        super(username, "Guest");
    }

    @Override
    public void accessSystem() {
        System.out.println("Guest access granted.");
    }
}
