package ui;

import javax.swing.*;
import java.awt.*;
import manager.StudentManager;
import model.Student;

public class ViewStudentFrame extends JFrame {
    public ViewStudentFrame(StudentManager manager) {
        setTitle("View Students");
        setSize(400, 300);
        setLocationRelativeTo(null);
        setResizable(false);

        DefaultListModel<String> model = new DefaultListModel<>();
        for (Student s : manager.getAllStudents()) {
            model.addElement("• " + s.getDetails());
        }

        JList<String> list = new JList<>(model);
        list.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(list);

        scrollPane.setBorder(BorderFactory.createTitledBorder("Student Records"));
        add(scrollPane, BorderLayout.CENTER);
    }
}
