package ui;

import javax.swing.*;
import java.awt.*;
import manager.StudentManager;
import model.Student;

public class AddStudentFrame extends JFrame {
    public AddStudentFrame(StudentManager manager) {
        setTitle("Add New Student");
        setSize(400, 350);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel(new GridLayout(5, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        panel.setBackground(new Color(250, 250, 250));

        JLabel idLabel = new JLabel("Student ID:");
        JLabel nameLabel = new JLabel("Name:");
        JLabel majorLabel = new JLabel("Major:");
        JLabel gpaLabel = new JLabel("GPA:");

        JTextField idField = new JTextField();
        JTextField nameField = new JTextField();
        JTextField majorField = new JTextField();
        JTextField gpaField = new JTextField();

        JButton addButton = new JButton("✅ Add Student");
        addButton.setBackground(new Color(144, 238, 144));
        addButton.setFont(new Font("SansSerif", Font.BOLD, 14));

        panel.add(idLabel); panel.add(idField);
        panel.add(nameLabel); panel.add(nameField);
        panel.add(majorLabel); panel.add(majorField);
        panel.add(gpaLabel); panel.add(gpaField);
        panel.add(new JLabel()); panel.add(addButton);

        add(panel);

        addButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                String name = nameField.getText();
                String major = majorField.getText();
                double gpa = Double.parseDouble(gpaField.getText());

                Student s = new Student(id, name, major, gpa);
                manager.addStudent(s);

                JOptionPane.showMessageDialog(this, "Student added!");
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Invalid input. Try again.");
            }
        });
    }
}
