package ui;

import javax.swing.*;
import java.awt.*;
import manager.StudentManager;

public class MainFrame extends JFrame {
    public MainFrame(StudentManager manager) {
        setTitle("Student Management System - Home");
        setSize(450, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JLabel welcomeLabel = new JLabel("Welcome, Ashraf Awwad!", JLabel.CENTER);
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 20));
        welcomeLabel.setForeground(new Color(0, 51, 102));

        JButton addBtn = new JButton("➕ Add Student");
        JButton viewBtn = new JButton("📋 View Students");

        Font btnFont = new Font("SansSerif", Font.BOLD, 16);
        addBtn.setFont(btnFont);
        viewBtn.setFont(btnFont);
        addBtn.setBackground(new Color(102, 153, 255));
        viewBtn.setBackground(new Color(102, 255, 178));
        addBtn.setForeground(Color.BLACK);
        viewBtn.setForeground(Color.BLACK);

        JPanel panel = new JPanel(new GridLayout(3, 1, 15, 15));
        panel.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));
        panel.add(welcomeLabel);
        panel.add(addBtn);
        panel.add(viewBtn);
        panel.setBackground(Color.WHITE);

        add(panel);

        addBtn.addActionListener(e -> new AddStudentFrame(manager).setVisible(true));
        viewBtn.addActionListener(e -> new ViewStudentFrame(manager).setVisible(true));
    }
}
